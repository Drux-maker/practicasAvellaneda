package hipotenusa2;

import java.util.Scanner;

public class Hipotenusa2 {
    public static void main(String[] args) {
        Scanner lectorTeclado = new Scanner(System.in);
        int cateto1, cateto2;
        String unidad;
        System.out.print("¿Cual es el cateto del triangulo?: ");
        cateto1 = lectorTeclado.nextInt();
        System.out.print("¿Cual es el otro?: ");
        cateto2 = lectorTeclado.nextInt();
        System.out.print("¿Cual es la medida?: ");
        unidad = lectorTeclado.next();
        double hipotenusa = Math.sqrt(cateto1*cateto1 + cateto2*cateto2);
        System.out.println("la hipotenusa del triangulo es: " + hipotenusa +" " +unidad);
        
        
    }
    
}

