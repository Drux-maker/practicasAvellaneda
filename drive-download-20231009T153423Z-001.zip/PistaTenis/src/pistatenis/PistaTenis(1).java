package pistatenis;

import java.util.Scanner;

public class PistaTenis {

    
    public static void main(String[] args) {
        Scanner lectorTeclado = new Scanner(System.in);
        String Luces;      
        int dia, pista;
        System.out.println("Que dia de la semana quieres jugar:");
        dia = lectorTeclado.nextInt();
        switch (dia) {
            case 1:
                String nombreDia = "Lunes";
                System.out.println("¿Quieres luces artificiales?");
                lectorTeclado.nextLine();
                Luces = lectorTeclado.nextLine();                
                System.out.println("Tienes disponibles las pistas 1, 2 y 3:");
                pista = lectorTeclado.nextInt();
                System.out.println("Tu reserva se ha completado");
                System.out.println("Sera el dia:"+ nombreDia);
                System.out.println("En la pista:"+ pista );
                System.out.println("Luces:"+ Luces );
                break;
            case 2:
                nombreDia = "Martes";
                System.out.println("¿Quieres luces artificiales?");
                lectorTeclado.nextLine();
                Luces = lectorTeclado.nextLine();
                System.out.println("Tienes disponibles las pistas 4, 5 y 6:");
                pista = lectorTeclado.nextInt();
                System.out.println("Tu reserva se ha completado");
                System.out.println("Sera el dia:"+ nombreDia);
                System.out.println("En la pista:"+ pista );
                System.out.println("Luces:"+ Luces );
                break;
            case 3:
                nombreDia = "Miercoles";
                System.out.println("¿Quieres luces artificiales?");
                lectorTeclado.nextLine();
                Luces = lectorTeclado.nextLine();
                System.out.println("Tienes disponibles las pistas 1, 4 y 7:");
                pista = lectorTeclado.nextInt();
                System.out.println("Tu reserva se ha completado");
                System.out.println("Sera el dia:"+ nombreDia);
                System.out.println("En la pista:"+ pista );
                System.out.println("Luces:"+ Luces );
                break;
            default:
                System.out.println("No hay pistas libres ese dia");
                                
        
             
        } 
        
      
    
    
        }
    }
