package conversiones;
public class Conversiones {
    public static void main(String[] args) {
        double vbleTipoDouble2 = 4.5;
        int vbleTipoInt2;
        vbleTipoInt2 = (int)vbleTipoDouble2;
        System.out.println("Explícita: Valor de double: " + vbleTipoDouble2);
        System.out.println("Explícita: Valor de int: " + vbleTipoInt2);
    }
    
}
