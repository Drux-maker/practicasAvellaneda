package calculadoraedad;

public class CalculadoraEdad {

    public static void main(String[] args) {
        int dia1, dia2, mes1, mes2, año1, año2;
        dia1 = 22;
        dia2 = 18;
        mes1 = 9;
        mes2 = 8;
        año1 = 2023;
        año2 = 2005;
        if(año1>año2){
            System.out.println("tu edad es: " + (año1 - año2) + " años " + (mes1-mes2) +" mes " + (dia1 - dia2) +  " dias");
        
        
        
        }
    }
    
}
