package tablamultiplicar;

public class TablaMultiplicar {

    public static void main(String[] args) {
    int x = 2, multiplicador = 0;
    System.out.println("la tabla del dos es:");
    System.out.println("x * multiplicador " + (multiplicador * x));
    multiplicador += 1;
    System.out.println("x * multiplicador " + (multiplicador * x));
    multiplicador += 1;
    System.out.println("x * multiplicador " + (multiplicador * x));
    multiplicador += 1;
    System.out.println("x * multiplicador " + (multiplicador * x));
    multiplicador += 1;
    System.out.println("x * multiplicador " + (multiplicador * x));
    multiplicador += 1;
    System.out.println("x * multiplicador " + (multiplicador * x));
    multiplicador += 1;
    System.out.println("x * multiplicador " + (multiplicador * x));
    multiplicador += 1;
    System.out.println("x * multiplicador " + (multiplicador * x));
    multiplicador += 1;
    System.out.println("x * multiplicador " + (multiplicador * x));
    multiplicador += 1;
    System.out.println("x * multiplicador " + (multiplicador * x));
    multiplicador += 1;
    System.out.println("x * multiplicador " + (multiplicador * x));
    
    
    }
    
}
