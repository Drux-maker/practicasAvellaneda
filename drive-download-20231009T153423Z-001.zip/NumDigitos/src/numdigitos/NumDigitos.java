package numdigitos;

import java.util.Scanner;

public class NumDigitos {

    public static void main(String[] args) {
        Scanner lectorTeclado = new Scanner(System.in);
        int numero, digitos;
        numero = 0;
        digitos = 0;
        System.out.println("Elige un numero y te dire cuantos digitos tiene.");
        numero = lectorTeclado.nextInt();
        if(numero<10 && numero>0){
            System.out.println("El numero tiene un digito");        
        }
        if(numero>=10 && numero<100){
            System.out.println("El numero tiene dos digitos");        
        }
        if(numero>=100 && numero<1000){
            System.out.println("El numero tiene tres digitos");        
        }
        if(numero>=1000 && numero<10000){
            System.out.println("El numero tiene cuatro digitos");        
        }
        if(numero>=10000 && numero<100000){
            System.out.println("El numero tiene cinco digitos");        
        }
        while(numero>=100000){
            System.out.println("No lose paco son muchos digitos");
            break;        
        }
    }
    
}
