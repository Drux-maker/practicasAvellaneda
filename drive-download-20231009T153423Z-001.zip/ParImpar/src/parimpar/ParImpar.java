
package parimpar;

import java.util.Scanner;

public class ParImpar {

    public static void main(String[] args) {
        Scanner lectorTeclado = new Scanner(System.in);
        int numero;
        System.out.print("¿Cual es el numero: ");
        numero = lectorTeclado.nextInt();
        if (numero%2 == 0){
            System.out.print("El numero es par");
            }
        else {
            System.out.print("El numero es impar ");
        
                    
        }

    }
    
}
