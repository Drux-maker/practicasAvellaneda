
package tablabucle2;

public class TablaBucle2 {

    public static void main(String[] args) {
        int m, g;
        m = 15;
        g = 11;
        while (g<=m){
            System.out.print(g +" ");
            g = g+1;
            while (g==m && m<=50){ 
                System.out.println(g +" ");
                g = g+6;
                m = m+10;
            }
        }
    
    
    }
    
}
