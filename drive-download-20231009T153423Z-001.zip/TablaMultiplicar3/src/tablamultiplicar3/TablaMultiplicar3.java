package tablamultiplicar3;

public class TablaMultiplicar3 {

    public static void main(String[] args) {
    int numero = 8;
    for(int multi= 0; multi <= 10; multi += 1)          {
        System.out.println("multiplicación = " + (numero * multi));
                                                        }
                                            }    
                                }       
