
package ejercicio4;

public class Ejercicio4 {

    public static void main(String[] args) {
        int a, b, c, d, e, f;
        a = 2;
        b = 3;
        c = 7;
        d = 1;
        e = 9;
        f = 4;
        System.out.println("El codigo postal es:" +(a + b + c + d + e + f));
    }
    
}
