package parking;

import java.util.Scanner;

public class Parking {
    public static void main(String[] args) {
        int horas, minutos, total, total60, total120, total3000;
        
        Scanner lectorTeclado = new Scanner(System.in); 
        System.out.print("¿Cuantas horas a estado estacionado su vehiculo? ");
        horas = (lectorTeclado.nextInt()*60);
        System.out.print("¿Y cuantos minutos? ");
        minutos = lectorTeclado.nextInt();
        
        total = minutos+horas;
        if (total <= 60 ){
            total60 = total;
            System.out.print("Entonces debes pagar: " + (total60*0.1)+" euros");           
            }
        if (total>60 & total<=180) {
            total120 = total-60;
            System.out.print("Entonces debes pagar: " + ((total120*0.07)+(60*0.1)) +" euros");
            }
        if (total>180 & total<=3000){
            total3000 = total-180;
            System.out.print("Entonces debes pagar: " + ((total3000*0.05)+(120*0.07)+(60*0.1))+" euros");
            }
        if (total>3000){
            System.out.print("El coche se encuentra en el depósito. Recibirá una multa en su domicilio. ");
            }        
    }    
}
