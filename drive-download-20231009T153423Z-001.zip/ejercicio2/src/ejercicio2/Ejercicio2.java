package ejercicio2;

public class Ejercicio2 {

    public static void main(String[] args) {
        int x, y, s;
        x = 1;
        System.out.println("x vale: " + x);
        y = 2;
        System.out.println("y vale: " + y);
        float vbleR = 1.56f;
        double vbleS = (x + vbleR);
        System.out.println("r vale:" + vbleR);
        System.out.println("r mas x es:" + (vbleR+x));
        System.out.println("y si le sumas y es:" + (vbleS * y));
        
        
        
         
    }
    
}
