package parking2;

import java.util.Scanner;

public class Parking2 {

    public static void main(String[] args) {
        int horas, minutos, total, total60, total120, total3000;
        Scanner lectorTeclado = new Scanner(System.in); 
        System.out.print("¿Cuantas horas a estado estacionado su vehiculo? ");
        horas = (lectorTeclado.nextInt()*60);
        System.out.print("¿Y cuantos minutos? ");
        minutos = lectorTeclado.nextInt();
        total = minutos+horas;
        total60 = 0;
        total3000 = 0;
        total120 = 0;        
        while(total <= 3000){
            while(total > 180) {
                total3000 = (int) ((int) ((total-180)*0.05)+(120*0.07)+(60*0.1));
                break;
            }     
            while(total <=180) {
                total120 = (int) (((total-60)*0.07)+6);
                break;
            }
            while(total <= 60) {
                total60 = (int) (total*0.1);
                total120 = 0;
                break;
            }
            System.out.print("Tienes que pagar:" +(total3000+total120+total60) +" euros");
            break;
        }
        if(total>3000){
           System.out.print("El coche esta en el deposito");
        }
                
    }
    
}
