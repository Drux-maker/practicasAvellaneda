Public class tresenraya {

    public static void main(String[] args) {
        // Texto + nueva línea
        System.out.println("I---------I--------I--------I");
        System.out.println("I    x    I    0   I    0   I");
        System.out.println("I---------I--------I--------I");
        System.out.println("I    0    I    x   I    0   I");
        System.out.println("I---------I--------I--------I");
        System.out.println("I    0    I    0   I    x   I");
        System.out.println("I---------I--------I--------I");
        
    }
    
}

