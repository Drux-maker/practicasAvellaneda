package parking3;

import java.util.Scanner;

public class Parking3 {

    public static void main(String[] args) {
        int horas, minutos, total;
        Scanner lectorTeclado = new Scanner(System.in); 
        System.out.print("¿Cuantas horas a estado estacionado su vehiculo? ");
        horas = (lectorTeclado.nextInt()*60);
        System.out.print("¿Y cuantos minutos? ");
        minutos = lectorTeclado.nextInt();
        total = minutos+horas;       
        while(total <= 3000){
            int pagar;
            while(total > 180) {
                pagar = pagar+0.05;
                break;
            }     
            while(total <=180 && total > 60) {
                pagar = pagar+0.07;
                break;
            }
            while(total <= 60) {
                pagar = pagar+0.1;
                break;
            }
            System.out.print("Tienes que pagar:" +pagar +" euros");
            break;
        }
        if(total>3000){
           System.out.print("El coche esta en el deposito");
        }
                
    }
    
}
