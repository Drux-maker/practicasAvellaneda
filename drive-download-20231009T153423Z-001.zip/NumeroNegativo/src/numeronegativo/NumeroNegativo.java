package numeronegativo;

import java.util.Scanner;

public class NumeroNegativo {

    public static void main(String[] args) {
        Scanner lectorTeclado = new Scanner(System.in);
        int numero, contador, par, impar, nimpar;
        numero = 0;
        boolean flag = true;
        par = 0;
        contador = 0;
        impar = 0;
        nimpar = 0;
        while(flag){
            System.out.println("Elige un numero ");
            numero = lectorTeclado.nextInt();            
            if(numero%2 == 0 && numero>par && numero>0){
                par = numero;
            }
            if(numero%2 != 0 && numero > 0){
                impar = (numero + impar);
                nimpar = nimpar+1;
            } 
            if (numero < 0){
                flag = false;
            }
            if (numero >= 0){
                contador = contador+1;
            }
        }
        if(numero<0){
            System.out.println("Has escrito "+ contador + " numeros.");
            System.out.println("El par mayor es el "+ par);
            System.out.println("La media de impares es "+ (impar/nimpar));
        }
        
    }
    
}
