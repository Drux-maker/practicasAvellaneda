package tablamultiplicar2;

public class TablaMultiplicar2 {

    public static void main(String[] args) {
        int numero = 8;
        int multi = -1;
        while (multi < 10){
            multi += 1;  
            System.out.println("multiplicación = " + (numero * multi));
            }            

    }
    
}
