package tablabucle;


public class TablaBucle {


    public static void main(String[] args) {
        int m = 10;
        while (10<=m && m<15){
            System.out.print(m +" ");
            m++;
        
        }
        m=20;
        System.out.println();
        while (20<=m && m<25){
            System.out.print(m +" ");
            m++;
        
        }
        m=30;
        System.out.println();
        while (30<=m && m<35){
            System.out.print(m +" ");
            m++;
        
        }
        m=40;
        System.out.println();
        while (40<=m && m<45){
            System.out.print(m +" ");
            m++;
        
        }
        m=50;
        System.out.println();
        while (50<=m && m<55){
            System.out.print(m +" ");
            m++;
        
        }
        
        }

    }
