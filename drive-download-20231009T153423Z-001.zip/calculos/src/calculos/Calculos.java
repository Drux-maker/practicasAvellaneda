package calculos;

import java.util.Scanner;

public class Calculos {
    public static void main(String[] args) {
        Scanner lectorTeclado = new Scanner(System.in);
        int numero1, numero2;
        System.out.print("¿Que numero quieres que sume, multiplique, divida y reste?: ");
        numero1 = lectorTeclado.nextInt();
        System.out.print("¿Cual es el otro numero?: ");
        numero2 = lectorTeclado.nextInt();
        System.out.println("La suma es: " +(numero1 + numero2));        
        System.out.println("La multiplicacion es: " +(numero1 * numero2));        
        System.out.println("La division es: " +(numero1 / numero2));        
        System.out.println("La resta es: " +(numero1 - numero2));
    }
    
}