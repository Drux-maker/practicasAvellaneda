package contraseña;

import java.util.Scanner;


public class Contraseña {
    public static void main(String[] args) {
        Scanner lectorTeclado = new Scanner(System.in);
        int fallo = 1;

        while(fallo<=2){
        System.out.print("Escribe la contraseña : ");
        String contraseña = lectorTeclado.nextLine();
        String comparador = "Jimenez.23?";
        if (contraseña.equals(comparador)){
            System.out.println("La contraseña es valida");
            break;
            }
        else {
            System.out.println("La contraseña no es valida escribe otra contraseña ");
            fallo = fallo+1;
        }
        
        }
        while(fallo==3){
        System.out.print("Escribe la contraseña : ");
        String contraseña = lectorTeclado.nextLine();
        String comparador = "Jimenez.23?";
        if (contraseña.equals(comparador)){
            System.out.println("La contraseña es valida");
            break;
            }
        else {
            System.out.println("La contraseña no es valida bloqueando dispositivo ");
            fallo = fallo+1;
        }
        
        }
    }
}