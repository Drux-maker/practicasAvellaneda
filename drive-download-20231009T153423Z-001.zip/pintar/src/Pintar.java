Public class pintar {

    public static void main(String[] args) {
        // Texto + nueva línea
        System.out.println("\033[33m@@@@@@@@");
        System.out.println("\033[33m@ \033[32mx  x \033[33m@");
        System.out.println("\033[33m@  \033[31muu  \033[33m@");
        System.out.println("\033[33m@@@@@@@@");
        
    }
    
}

