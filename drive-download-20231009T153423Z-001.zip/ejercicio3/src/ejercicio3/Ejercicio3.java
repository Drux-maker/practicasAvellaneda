package ejercicio3;

public class Ejercicio3 {

    public static void main(String[] args) {
                // Variables que almacenan caracteres
        char s, l , o;
        s = 's';
        l = 'o';
        o = 'l';
                
        System.out.println("La palabra es: " + s + l + o);
    }
    
}
