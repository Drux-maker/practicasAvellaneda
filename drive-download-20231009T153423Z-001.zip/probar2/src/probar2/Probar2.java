
package probar2;

public class Probar2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("\033[35muno");
        System.out.println("dos");
                    // TODO code application logic here
        
        
    }
    
}
