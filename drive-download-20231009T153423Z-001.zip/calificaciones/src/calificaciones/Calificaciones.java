package calificaciones;

public class Calificaciones {

    public static void main(String[] args) {
        int matematicas, lengua, fisica, ingles;
        matematicas = 7;
        lengua = 8;
        fisica = 9;
        ingles = 6;
        boolean r;
        r = (matematicas > fisica && matematicas > ingles && matematicas > lengua);
        System.out.println("matematicas = " + r);
        r = (lengua > fisica && lengua > ingles && lengua > matematicas);
        System.out.println("lengua = " + r);
        r = (fisica > matematicas && fisica > ingles && fisica > lengua);
        System.out.println("fisica = " + r);
        r = (ingles > fisica && ingles > matematicas && ingles > lengua);
        System.out.println("ingles = " + r);
      
        
        
        }
    }
