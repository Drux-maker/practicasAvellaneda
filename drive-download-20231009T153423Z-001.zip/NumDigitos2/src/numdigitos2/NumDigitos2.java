package numdigitos2;

import java.util.Scanner;

public class NumDigitos2 {

    public static void main(String[] args) {
        Scanner lectorTeclado = new Scanner(System.in);
        int numero, resto, digitos;
        digitos = 0;
        System.out.println("Elige un numero y te los digitos tiene.");
        numero = lectorTeclado.nextInt();
        while(true){
            resto = numero%10;
            numero = numero/10;
            System.out.println("Un digito es el: " +resto);
            digitos++;            
            if(digitos >= 5 || numero == 0){
                System.out.println("Nose que digitos son solo se contar cinco ");
                break;
            
            }    
        }
    }
    
}
