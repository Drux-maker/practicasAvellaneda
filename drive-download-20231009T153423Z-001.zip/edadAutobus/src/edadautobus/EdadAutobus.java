package edadautobus;

import java.util.Scanner;
import java.time.LocalDate;
import java.time.Period;

public class EdadAutobus {
    public static void main(String[] args) {
        Scanner lectorTeclado = new Scanner(System.in);
        int dia, mes, año;
        System.out.print("¿Dime el dia en el que naciste? ");
        dia = lectorTeclado.nextInt();
        System.out.print("¿Dime el mes en el que naciste? ");
        mes = lectorTeclado.nextInt();
        System.out.print("¿Dime el año en el que naciste? ");
        año = lectorTeclado.nextInt();
        lectorTeclado.close();
        LocalDate fechaActual = LocalDate.now();
        LocalDate fechaEspec = LocalDate.of(año, mes, dia);
        Period diferencia = Period.between(fechaEspec, fechaActual);
        if(diferencia.getYears() <= 7 || diferencia.getYears() >= 65){
            System.out.print("Entonces no debes pagar nada ");
            }
        else if (diferencia.getYears()<26 & diferencia.getYears()>7) {
            System.out.print("Entonces debes pagar un euro ");
            }
        else {
            System.out.print("Entonces debes pagar dos euros ");
        }
        }
    
}
