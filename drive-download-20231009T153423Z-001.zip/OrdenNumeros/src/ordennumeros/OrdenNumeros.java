
package ordennumeros;

import java.util.Scanner;

public class OrdenNumeros {

    public static void main(String[] args) {
        Scanner lectorTeclado = new Scanner(System.in);      
        int numero1, numero2, numero3;
        System.out.println("Escribe un numero: ");
        numero1 = lectorTeclado.nextInt();
        System.out.println("Escribe otro numero: ");
        numero2 = lectorTeclado.nextInt();
        System.out.println("Escribe otro numero: ");
        numero3 = lectorTeclado.nextInt();
        System.out.println("Los numeros ordenados son: ");
        switch (1){
            case 1:
                if (numero1>numero2 & numero1>numero3 ){
                System.out.println(numero1);
                numero1 = 0;
                }
                if (numero3>numero2 & numero3>numero1 ){
                System.out.println(numero3);
                numero3 = 0;
                }
                if (numero2>numero1 & numero2>numero3 ){
                System.out.println(numero2);
                numero2 = 0;
                }
            case 2:
                if (numero2>numero1 & numero2>numero3 ){
                System.out.println(numero2);
                numero2 = 0;
                }
                if (numero3>numero2 & numero3>numero1 ){
                System.out.println(numero3);
                numero3 = 0;
                }
                if (numero1>numero2 & numero1>numero3 ){
                System.out.println(numero1);
                numero1 = 0;
                }
            case 3:
                if (numero3>numero2 & numero3>numero1 ){
                System.out.println(numero3);
                numero3 = 0;
                }
                if (numero1>numero2 & numero1>numero3 ){
                System.out.println(numero1);
                numero1 = 0;
                }
                if (numero2>numero1 & numero2>numero3 ){
                System.out.println(numero2);
                numero2 = 0;
                }       
        
        }
    }
    
}
