Public class Probar {

    public static void main(String[] args) {
        
        System.out.println("\033[35m uno");
        System.out.println("dos");
            
    }
    
}
