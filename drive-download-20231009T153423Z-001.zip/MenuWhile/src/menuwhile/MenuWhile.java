package menuwhile;

import java.util.Scanner;

public class MenuWhile {

    public static void main(String[] args) {
        Scanner lectorTeclado = new Scanner(System.in);
        System.out.println("Elige un menu del 1 al 3: ");
        int m;        
        m = lectorTeclado.nextInt();                
        while (m > 3){
            System.out.println("No has elegido un menu valido, elige otro: ");
            m = lectorTeclado.nextInt();
                       
        }
        while (m <= 3){
            switch (m) {
                case 1:
                    System.out.println("Has elegido el menu 1  ");
                    return;
                case 2:
                    System.out.println("Has elegido el menu 2  ");
                    return;
                case 3:
                    System.out.println("Has elegido el menu 3  ");
                    return;

                
            }
        }

        
    }
    
}
