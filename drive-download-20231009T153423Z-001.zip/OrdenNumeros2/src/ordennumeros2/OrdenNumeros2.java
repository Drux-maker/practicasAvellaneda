package ordennumeros2;

import java.util.Scanner;

public class OrdenNumeros2 {
    public static void main(String[] args) {
        int numero1;
        int numero2;
        int numero3;
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Ingresa el primer número: ");
            numero1 = scanner.nextInt();
            System.out.print("Ingresa el segundo número: ");
            numero2 = scanner.nextInt();
            System.out.print("Ingresa el tercer número: ");
            numero3 = scanner.nextInt();
        }

        int mayor, medio, menor;

        // Comparamos los números utilizando switch
        switch (numero1) {
            case 1:
                switch (numero2) {
                    case 2:
                        switch (numero3) {
                            case 3:
                                mayor = numero1;
                                medio = numero2;
                                menor = numero3;
                                break;
                            default:
                                mayor = numero1;
                                medio = numero3;
                                menor = numero2;
                                break;
                        }
                        break;
                    default:
                        switch (numero3) {
                            case 3:
                                mayor = numero3;
                                medio = numero1;
                                menor = numero2;
                                break;
                            default:
                                mayor = numero2;
                                medio = numero1;
                                menor = numero3;
                                break;
                        }
                        break;
                }
                break;
            case 2:
                switch (numero3) {
                    case 3:
                        mayor = numero3;
                        medio = numero2;
                        menor = numero1;
                        break;
                    default:
                        mayor = numero2;
                        medio = numero1;
                        menor = numero3;
                        break;
                }
                break;
            default:
                if (numero2 > numero3) {
                    mayor = numero1;
                    medio = numero2;
                    menor = numero3;
                } else {
                    mayor = numero1;
                    medio = numero3;
                    menor = numero2;
                }
                break;
        }

        System.out.println("Números ordenados de mayor a menor: " + mayor + ", " + medio + ", " + menor);
            }
        }

